<link rel="stylesheet" href ="{{asset('css/styles.css')}}">
<link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
<script src="https://code.iconify.design/iconify-icon/1.0.3/iconify-icon.min.js"></script>
<script src="{{asset('js/select.js')}}"> </script>



@yield('isi')