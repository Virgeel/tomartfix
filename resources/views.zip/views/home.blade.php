@extends('layouts.main')

@section('isi')
    


<html>
<title>

Tomart Kediri

</title>
<div class="background">
    
<body style="margin: 0;">
    <div style="text-align:center;padding-top:200px;padding-bottom:3px">

    <img src = "{{asset('images/logo.png')}}">

    </div>

    <div style="text-align:center">
        <a href="/login">
    <button class="loginbutton">
        LOGIN
    </button>
</a>
</div>


   

</body>
</div>
</html>

@endsection

